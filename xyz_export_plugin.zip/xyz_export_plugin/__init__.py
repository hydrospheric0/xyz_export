def classFactory(iface):
    from .xyz_export_main import XYZExport
    return XYZExport(iface)
